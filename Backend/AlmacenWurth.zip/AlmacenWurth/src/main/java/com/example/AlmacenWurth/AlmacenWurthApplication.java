package com.example.AlmacenWurth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlmacenWurthApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlmacenWurthApplication.class, args);
	}

}
