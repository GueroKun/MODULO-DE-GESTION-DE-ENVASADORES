package com.example.AlmacenWurth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlmacenWurthApplicationTests {

	@Test
	void contextLoads() {
	}

}
